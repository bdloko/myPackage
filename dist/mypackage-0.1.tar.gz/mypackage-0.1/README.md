# myPackage
#The first EDSA hackathon

#The function we are going to create will perform the task of returning the top-n items in an array, in descending order.

#To do this, we will create an algorithm not too dissimilar to the bubble sort.
